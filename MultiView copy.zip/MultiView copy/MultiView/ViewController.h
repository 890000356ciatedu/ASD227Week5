//
//  ViewController.h
//  MultiView
//
//  Created by user168329 on 1/27/21.
//  Copyright © 2021 Ciat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (retain, nonatomic) IBOutlet UITextField *height;
@property (retain, nonatomic) IBOutlet UITextField *weight;
@property (retain, nonatomic) IBOutlet UISegmentedControl *measure;
@property (retain, nonatomic) IBOutlet UISwitch *male;
@property (retain, nonatomic) IBOutlet UISwitch *female;

- (IBAction)maleSelected:(id)sender;
- (IBAction)femaleSelected:(id)sender;
- (IBAction)resetBtn:(id)sender;

@end


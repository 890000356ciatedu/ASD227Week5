//
//  SceneDelegate.h
//  MultiView
//
//  Created by user168329 on 1/27/21.
//  Copyright © 2021 Ciat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

